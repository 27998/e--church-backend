package com.auca.echurch.model;

import java.util.UUID;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;


@Entity 
@Table (name="member")
public class Member {

    @Id 
    @GeneratedValue(strategy=GenarationType.UUID)
    private UUID id;
    private String firstName;
    private String lastName;
    @Column(unique=true)
    private String memeberNumber;
    private String phone;
    private String cell;
    public UUID getId() {
        return id;
    }
    public void setId(UUID id) {
        this.id = id;
    }
    public String getFirstName() {
        return firstName;
    }
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }
    public String getLastName() {
        return lastName;
    }
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }
    public String getMemeberNumber() {
        return memeberNumber;
    }
    public void setMemeberNumber(String memeberNumber) {
        this.memeberNumber = memeberNumber;
    }
    public String getPhone() {
        return phone;
    }
    public void setPhone(String phone) {
        this.phone = phone;
    }
    public String getCell() {
        return cell;
    }
    public void setCell(String cell) {
        this.cell = cell;
    }



}
    