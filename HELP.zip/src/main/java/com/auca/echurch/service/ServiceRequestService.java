package com.auca.echurch.service;

import org.springframework.beans.factory.annotation.Autowired;

@Service
public class ServiceRequestService {

    @Autowired 
    private ServiceRequestRepository serviceRequestRepository;

    public String save(ServiceRequest serviceRequest){
        serviceRequestRepository.save(serviceRequst);
        return "Service requst saved successfully";
    }
    public List<ServiceRequest>getAll(){
        return serviceRequestRepository.findAll();
    }
    public Optional<ServiceRequest>getById(UUID id){
        return serviceRequestRepository.findById(id);

    }
    public String update(UUID id, ServiceRequest serviveRequest){
        if(!serviceRequestRepository.existsById(id)){
            return "The service request with that id does not exist";
        }
        serviceRequest.setId(id);
        serviceRequestRepository.save(serviceRequest);
        return "Service request updated successfully";
    }
    public String delete(UUID id){
        if(!serviceRequestRepository.existsById(id)){
            return " The service request with that id does not exist";
        }
        serviceRequestRepository.deleteById(id);
        return "Service request deleted successfully";
    }
}
