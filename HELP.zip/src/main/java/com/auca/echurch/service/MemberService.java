package com.auca.echurch.service;

import com.auca.echurch.model.Member;

import java.util.UUID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import java.util.List;
import java.util.Optional;

@Service
public class MemberService {
  
    @Autowired 
    private MemberRepository memberRepository;
    public String save(Member member){
        return"Member saved successfully";
    }

public List<Member>getById(UUID id){
    return memberRepository.findById(id);
}

public Optional<Member>getById(UUID id){
    return memeberRepository.findById(id);
}

public String update(UUID id, Member memeber){
    if(!memeberRepository.existsById(id)){
        return "The  memebre with that id does not exist";
    }
    memeber.setId(id);
    memeberRepository.save(memeber);
    return "Member updated successfulluy";
}
public String delete(UUID id){
    if(!memebreRepository.existsById(id)){
        return "The memeber with that id does not exist";

    }
    memeberRepository.deleteById(id);
    return"Member deleted successfully";
}
}
