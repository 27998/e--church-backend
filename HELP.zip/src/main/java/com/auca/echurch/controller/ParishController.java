package com.auca.echurch.controller;

import java.util.HashSet;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RestController;

@RestController 
@RequestMapping("/api/parishes")
public class ParishController {

    @Autowired 
    private parishService parishService;

    postMapping("/save")
    public ResponseEntity<String>save(@RequestBody Parish parish){
        String message = parishService.save(parish);
        return new  ResponseEntity<>(parishService.getAll(),HttpStatus.CREATED);
    }

    @GetMapping("/all")
    public ResponseEntity<List<Parish>>getAll(){
        return new ResponseEntity<>(parishService.getAll(), HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Object> getBy(@PathVariable UUID id){
        Optional<Parish>parish = parishService.getById(id);
        if (parish.isPresent()){
            return new ResponseEntity<>(parish.get(),HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>("The parish with that id does not exist",HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String>update(@PathVariable UUID id,
        @RequestBody Parish parish){
            String message = parishService.update(id,parish);
            if(message.equals("The parish with that id does not exist")){
                return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
            }
            else{
                return new ResponseEntity<>(message, HttpStatus.OK);
            }
        }
    
@DeleteMapping("/delete/{id}")
public ResponseEntity<String>delete(@PathVariable UUID id){
    String message = parishService.delete(id);
    if(message.equals("The parish with that id does not exist")){

    return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
}
else{
    return  new ResponseEntity<>(message,HttpStataus.OK);

}

}
}

