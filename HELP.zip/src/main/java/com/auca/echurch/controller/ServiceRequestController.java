package com.auca.echurch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.RestController;

import com.auca.echurch.model.ServiceRequest;

@RestController 
RequestMapping("/api/service-requests")
public class ServiceRequestController {
    @Autowired 
    private ServiceRequestService serviceRequestServive;
     
    @PostMapping("/save")
    public ResponseEntity<String>save(@RequestBody ServiceRequest serviceRequest){
        String message = serviceRequestService.save(serviceRequest);
        return new ResponseEntity<>(message,HttpStatus.CREATED);
    }

    @GetMapping("/{all}")
    public ResponseEntity<List<ServicesRequest>>getAll(){
        return new ResponseEntity<>(serviceRequestService.getAll(),
    HttpStatus.OK);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Object> getById (@PathVariable UUID id){
        Optional<ServiceRequest>serviceRequest = 
        serviveRequestService.getById(id);
        if(serviceRequest.isPresent()){
            return new ResponseEntity<>(serviceRequest.get(),
        HttpStatus.OK);
        }
        else{
            return new Response Entity<>("The service requst with that id does not exist",HttpStatus.NOT_FOUND);
        }
    }

    @PutMapping("/update/{id}")
    public ResponseEntity<String>update(@PathVariable UUID id,
        @RequestBody ServiceRequest serviceRequest ){
            String message = serviceRequestService.update(id, serviceRequest);
            if(message.equals("The service request with that id does not exist")){
                return new ResponseEntity<>(message,HttpStatus.NOT_FOUND);

            }
            else{
                return new ResponseEntity<>(message,HttpStatus.OK);
            }
        }

    @DeleteMapping("/delete/{id}")
    public ResponseEntity<String>delete(@PathVariable UUID id){
        String message = serviceRequestService.delete(id);
        if(message.equals("The service request with that id does not exist")){
            return new ResponseEntity<>(message,HttpStatus.NOT_FOUND);

        }
        else{
            return new ResponseEntity<>(message,HttpStatus.OK);
        }
    }

}
