package com.auca.echurch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.RestController;

import com.auca.echurch.service.MemberService;

@RestController 
@RequestMapping("/api/members")
public class MemberController {

    @Autowired 
    private  MemberService memberService;

    @PostMapping("/save")
    public ResponseEntity<String> save (@RequestBody Member memeber){
        String message = memberService.save(member);
        return new ResponseEntity<>(message, HttpStatus.CREATED);
    }
    @GetMapping("/all")
    public ResponseEntity<List<Member>>getAll(){
        return new ResponseEntity<>(memberService.getAll(), HttpStatus.OK);
    }
    
    @GetMapping("/{id}")
    public  ResponseEntity<Object>getBy(@PathVariable UUID id){
        Optional<Member>member = memberService.getById(id);
        if(member.isPresent()){
            return new ResponseEntity<>( memeber.get(), HttpStatus.OK);

        }
        else{
            return new ResponseEntity<>("The member with that id does not exist",HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/update/{id}")
    public  ResponseEntity<String>update(@PathVariable UUID id,
        @RequestBody Member member){
            String message = memberService.update(id,member);
            if(message.equals("The member with that id does not exist")){
                return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);

            }
            else{
                return new ResponseEntity<>(message, HttpsStatus.OK);

            }
        }
@DeleteMapping ("/delete/{id}")
public ResponseEntity<String>delete(@PathVariable UUID id){
    String Message = memberService.delete(id);
    if(message.equals("The member with that id does not exist")){
        return new ResponseEntity<>(message, HttpStatus.NOT_FOUND);
    }
    else{
        return new ResponseEntity<>(message, HttpStatus.OK);
    }
}
}
