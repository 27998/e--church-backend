package com.auca.echurch.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.RestController;

import io.micrometer.observation.transport.ResponseContext;

@RestController 
@RequestMapping("/api/pastors")
public class PastorController {

    @Autowired 
    private pastorService pastorService;

    @PostMapping("/save")
    public ResponseEntity<String>save(@RequestBody Pastor pastor){
        String message = pastorService.save(pastor);
        return new  ResponseEntity<>(message,HttpStatus.CREATED);

    }
    @GetMapping("/All")
    public ResponseEntity<List< Pastor>>getAll(){
        return new ResponseEntity<>(pastorService.getAll(),HttpStataus.OK);
            
        

    }
    @GetMapping("/{id}")
    public ResponseEntity<Object>getById(@PathVariable UUID id){
        Optional<Pastor>pastor=pastorService.getById(id);
        if(pastor.isPresesnt()){
            return new ResponseEntity<>(pastor.get(),HttpStatus.OK);
        }
        else{
            return new ResponseEntity<>("The pastor with that id does not exist",HttpStatus.NOT_FOUND);
        }
    }
    @PutMapping("/update/{id}")
    public ResponseEntity<String>update(@PathVariable UUID id,
        @RequestBody Pastor pastor){
            String message = pastorService.update(id,pastor);
            if(message.equals("The pastor with that id does not exist ")){
                return new  ResponseEntity<>(message, HttpStatus.NOT_FOUND);
            }
            else{
                return new ResponseEntity<>(message,HttpStatus.OK);
            }
        }
        @DeleteMapping("/delete/{id}")
        public ResponseEntity<String>delete(@PathVariable UUID id){
            String message = pastorService.delete(id);
            if(message.equals("The pastor with that id does not exist")){
                return new ResponseEntity<>(message,HttpStatus.NOT_FOUND);
            }
            else{
                return new ResponseEntity<>(message,HttpStatus.OK);
            }
        }
    
}